## Resource links in dataset 

Listed below are useful links in this dataset : 

* Link(http://gistmaps.itos.uga.edu/arcgis/rest/services/COD_External/NGA_EN/MapServer)
* Link(http://gistmaps.itos.uga.edu/arcgis/rest/services/COD_External/NGA_pcode/FeatureServer)
* Link(http://gistmaps.itos.uga.edu/arcgis/rest/services/COD_External/NGA_pcode/MapServer)
